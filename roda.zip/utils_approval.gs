// utils_approval.gs
// Pastikan helper approval tersedia sebagai global function di runtime Apps Script.
// Aman walau dipasang berulang: hanya didefinisikan jika belum ada.
(function () {
  try {
    if (typeof globalThis.isApproved_ !== 'function') {
      globalThis.isApproved_ = function (v) {
        if (v === true || v === 1) return true;
        if (v === false || v === 0 || v == null) return false;
        var s = String(v).trim().toLowerCase();
        if (!s) return false;
        // Nilai-nilai yang dianggap "approved"
        return (
          s === 'true' ||
          s === 'ya' ||
          s === 'yes' ||
          s === 'y' ||
          s === 'ok' ||
          s === 'approve' ||
          s === 'approved' ||
          s === '1'
        );
      };
    }
  } catch (err) {
    // no-op; sangat jarang terjadi
  }
})();
